﻿define("epi-cms/component/SharedBlocksViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi-cms/widget/ContextualContentForestStoreModel",
    "epi-cms/widget/viewmodel/HierarchicalListViewModel",

// command
    "epi-cms/command/NewContent",
    "epi-cms/command/ShowAllLanguages",

// resource
    "epi/i18n!epi/cms/nls/episerver.cms.components.createblock"
],

function (
// dojo
    declare,
    lang,
    when,
// epi
    ContextualContentForestStoreModel,
    HierarchicalListViewModel,

// command
    NewContentCommand,
    ShowAllLanguagesCommand,

// resource
    resCreateBlock
) {

    // module:
    //      epi-cms/component/SharedBlocksViewModel
    // summary:
    //      Handles search and tree to list browsing widgets.
    // tags:
    //      public

    return declare([HierarchicalListViewModel], {

        // treeStoreModelClass: [const] Function
        //      Class to use as model for the tree.
        treeStoreModelClass: ContextualContentForestStoreModel,

        _updateTreeContextCommandModels: function (model) {
            // summary:
            //      Update model of commands in case selected content is folder
            // tags:
            //      private

            this.inherited(arguments);

            var translateDelegate = lang.hitch(this.treeStoreModel, this.treeStoreModel.translate);
            this._commandRegistry.translate.command.set("model", model);
            this._commandRegistry.translate.command.set("executeDelegate", translateDelegate);

            this._commandRegistry.newBlockDefault.command.set("model", model);
        },

        _setupCommands: function () {
            // summary:
            //      Creates and registers the commands used.
            // tags:
            //      protected

            this.inherited(arguments);

            var customCommands = {
                newBlockDefault: {
                    command: new NewContentCommand({
                        contentType: "episerver.core.blockdata", // TODO: Take type indentifier from ShareBlock widget
                        iconClass: "epi-iconPlus",
                        label: resCreateBlock.command.label,
                        resources: resCreateBlock
                    })
                },
                allLanguages: {
                    command: new ShowAllLanguagesCommand({ model: this }),
                    order: 55
                }
            };

            this._commandRegistry = lang.mixin(this._commandRegistry, customCommands);

            this.pseudoContextualCommands.push(this._commandRegistry.newBlockDefault.command);
        }
    });
});