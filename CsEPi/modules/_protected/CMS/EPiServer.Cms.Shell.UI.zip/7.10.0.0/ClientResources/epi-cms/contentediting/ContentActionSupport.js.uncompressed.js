﻿define("epi-cms/contentediting/ContentActionSupport", [
// resources
    "epi/i18n!epi/cms/nls/episerver.cms.versionstatus"
],

function (
// resources
    res
) {

    var versionLocalizations = [];

    if (res) {
        versionLocalizations = [
            res.notcreated,
            res.rejected,
            res.checkedout,
            res.checkedin,
            res.published,
            res.previouslypublished,
            res.delayedpublish,
            res.expired
        ];
    }

    var actionSupport = {
        // summary:
        //    This class helps dealing with the content data structure:
        //      * decode the access level mask provided by content data store
        //      * determine if an action is supported for a given version statuse
        // tags:
        //    public static

        // versionStatus: Object
        //      Version status codes used in contentContext.status
        versionStatus: {
            NotCreated: 0,
            Rejected: 1,
            CheckedOut: 2,
            CheckedIn: 3,
            Published: 4,
            PreviouslyPublished: 5,
            DelayedPublish: 6,
            Expired: 7
        },

        versionLocalizations: versionLocalizations,

        getVersionStatus: function (status) {
            return this.versionLocalizations[status];
        },

        // action: Object
        //      Known actions on a contentData object
        action: {
            Create: "Create",
            Edit: "Edit",
            Delete: "Delete",
            CheckIn: "CheckIn",
            Save: "Save",
            Reject: "Reject",
            Publish: "Publish",
            Administer: "Administer"
        },

        // accessLevel: Object
        //      Access level components of the contentContext.accessMask bitmask.
        accessLevel: {
            NoAccess: 0,
            Read: 1,
            Create: 2,
            Edit: 4,
            CheckIn: 4,
            Delete: 8,
            Publish: 16,
            Administer: 32,
            FullAccess: 63
        },

        // saveAction: Object
        //      Options available when saving content
        saveAction: {
            /// Do not save data.
            None: 0x0,
            /// Save a page, leaving it in a checked out state.
            Save: 0x1,
            /// Save and check in page, creating a new version only if necessary.
            CheckIn: 0x2,
            /// Publish page, creating a new version only if necessary.
            Publish: 0x3,
            /// Reject a checked-in page.
            Reject: 0x4,
            /// Flag that is used to force the creation of a new version.
            ForceNewVersion: 0x80,
            /// Save and check in page, always updating the current version
            ForceCurrentVersion: 0x100,
            /// Does not validate the data against <see cref:"EPiServer.Validation.IValidationService"/>
            SkipValidation: 0x200,
            /// Save and check in page, creating a new version only if necessary and sets the content as delayed publish.
            DelayedPublish: 0x400
        },

        // sortOrder: Object
        //      Sort order of contentData, need to verify when change
        sortOrder: {
            None: 0,
            CreatedDescending: 1,
            CreatedAscending: 2,
            Alphabetical: 3,
            Index: 4,
            ChangedDescending: 5,
            Rank: 6,
            PublishedAscending: 7,
            PublishedDescending: 8
        },

        // providerCapabilities: Object
        //      Capabilities bitmask of a content provider
        providerCapabilities: {
            None: 0,
            Create: 1,
            Edit: 2,
            Delete: 4,
            Move: 8,
            Copy: 16,
            MultiLanguage: 32,
            Security: 64,
            Search: 128,
            PageFolder: 256,
            Wastebasket: 512
        },

        isActionAvailable: function (contentData, actionType, providerCapabilityType, skipMissingLanguageCheck, skipLanguageAccess) {
            // summary:
            //    Returns true if the given action type is authorized and represents an allowed state transition for the given contentData context.
            //    This also checks for the capability of content provider whether is configured to allow the action.
            //    If the specified contentData has the missingLanguageBranch property set it will return false.
            // tags:
            //    public

            if (!contentData) {
                return false;
            }

            if (!skipMissingLanguageCheck && contentData.capabilities && contentData.capabilities.language && contentData.missingLanguageBranch && contentData.missingLanguageBranch.isTranslationNeeded) {
                return false;
            }

            var access = skipLanguageAccess ? contentData.accessRights : contentData.accessMask;
            var actionAvailable = actionSupport.hasAccess(access, actionSupport.accessLevel[actionType]) &&
                                  actionSupport.canPerformAction(contentData, actionType);

            if (providerCapabilityType) {
                actionAvailable = actionAvailable && actionSupport.hasProviderCapability(contentData.providerCapabilityMask, providerCapabilityType);
            }

            return actionAvailable;
        },

        canPerformAction: function (contentContext, actionType) {
            // summary:
            //    Returns true if the action represents an allowed state transition.
            // tags:
            //    public

            // If the content is scheduled for published, we considered it locked for edit.
            if (contentContext.status === actionSupport.versionStatus.DelayedPublish &&
               (actionType === actionSupport.action.Edit || actionType === actionSupport.action.Publish)) {
                return false;
            }

            if (actionType === actionSupport.action.Publish) {
                // we can publish everything that's not already published or expired
                return !(contentContext.status === actionSupport.versionStatus.Published ||
                    contentContext.status === actionSupport.versionStatus.Expired);
            }
            if (actionType === actionSupport.action.CheckIn) {
                // we can make "not ready" (checkedout) or rejected content "ready to publish" (checkedin)
                return contentContext.status === actionSupport.versionStatus.CheckedOut ||
                    contentContext.status === actionSupport.versionStatus.Rejected;
            }
            if (actionType === actionSupport.action.Edit) {
                var readonlyVersion =
                    (contentContext.status === actionSupport.versionStatus.Published && !contentContext.isCommonDraft) ||
                    (contentContext.status === actionSupport.versionStatus.Expired && !contentContext.isCommonDraft) ||
                    contentContext.status === actionSupport.versionStatus.PreviouslyPublished ||
                    contentContext.status === actionSupport.versionStatus.CheckedIn ||
                    contentContext.status === actionSupport.versionStatus.DelayedPublish;

                return !(readonlyVersion || contentContext.isDeleted || contentContext.isWastebasket);
            }
            return true;
        },

        hasAccess: function (accesLevelMask, requiredAccessLevel) {
            // summary:
            //    Returs true if the required access is part of the given access mask.
            //    The access mask can be accessed from a contentData context or lightweight contentData object.
            // tags:
            //    public
            return (accesLevelMask & requiredAccessLevel) == requiredAccessLevel;
        },

        hasLanguageAccess: function (item) {
            // summary:
            //      Verify the current content have access with the given language or not
            // context: Object
            //      A content data or context object
            // tags:
            //      public

            if (!item) {
                return false;
            }

            // Get the language information from either the context or the content data since we don't know what type we have.
            var language = item.languageContext || item.missingLanguageBranch || item;

            return !language || (language.hasTranslationAccess && language.isPreferredLanguageAvailable); // Boolean
        },

        getPermissionMap: function (accesLevelMask) {
            // summary:
            //    Maps the given access mask onto an object, for example:
            //    { Read:true, Edit:true, Delete:false, Publish:false, Administer:false }
            // tags:
            //    public

            var map = {};
            for (var al in actionSupport.accessLevel) {
                map[al] = actionSupport.hasAccess(accesLevelMask, actionSupport.accessLevel[al]);
            }
            return map;
        },

        hasProviderCapability: function (providerCapabilityMask, requiredCapability) {
            // summary:
            //     Returs true if the required capabilty is part of the given content provider capability mask.
            // tags:
            //    public

            return (providerCapabilityMask & requiredCapability) == requiredCapability;
        }
    };
    return actionSupport;
});