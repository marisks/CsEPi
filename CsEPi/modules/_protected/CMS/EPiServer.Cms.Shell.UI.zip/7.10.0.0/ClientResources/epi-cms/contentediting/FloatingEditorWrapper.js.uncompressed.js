﻿define("epi-cms/contentediting/FloatingEditorWrapper", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/dom-geometry",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/has",
    "dojo/when",
// epi
    "epi/dependency",
    "epi/string",

    "epi/shell/widget/dialog/LightWeight",

    "epi-cms/contentediting/OverlayBasedEditorWrapper"
],

function (
// dojo
    array,
    declare,
    lang,

    domGeometry,

    aspect,
    Deferred,
    has,
    when,
// epi
    dependency,
    epiString,

    LightWeightDialog,

    OverlayBasedEditorWrapper
) {

    // module:
    //      epi-cms/contentediting/FlyoutEditorWrapper
    // summary:
    //      A lightweight dialog used for displaying property editors. This dialog doesn't contain any
    //      buttons, instead it will close when a user clicks on the overlay outside the dialog.
    // tags:
    //      public

    return declare([OverlayBasedEditorWrapper], {

        // formContainerWidgetType: String
        //      Special editor widget type
        formContainerWidgetType: "epi/shell/widget/FormContainer",

        destroy: function () {
            this._removeEditingFeatures();
            this._destroyDialog();
            this.inherited(arguments);
        },

        startEdit: function (params) {
            // summary:
            //    Start editing and show the dialog.
            // tags:
            //    public

            lang.mixin(this.editorParams, params);

            var self = this,
                def = new Deferred();

            self._destroyDialog();

            when(self._setupDialog(), function () {
                self._dialog.show();

                self.own(
                    aspect.after(self._dialog, "onAfterShow", function () {
                        self._startEdit(params);
                        self._onTryToStopWithInvalidValue();
                        def.resolve();
                    })
                );
            });

            return def;
        },

        _createDialog: function (/*Object*/editor) {
            // summary:
            //      Create dialog
            // editor:
            //      Editor object
            // tags:
            //      protected

            return new LightWeightDialog({
                title: this.propertyDisplayName,
                content: editor,
                duration: 350,
                snapToNode: this.blockDisplayNode,
                positioner: dependency.resolve("epi.shell.layout.PositioningUtility")
            });
        },

        _setupDialog: function () {
            var _formWidgets = {};

            //Define form's field created event handler.
            var onFieldCreatedHandler = function (fieldName, widget) {
                _formWidgets[fieldName] = widget;
            };

            //Define form's form created event handler.
            var onFormCreatedHandler = lang.hitch(this, function (formContainer) {
                // set parent for each child widget
                for (var fieldName in _formWidgets) {
                    var widget = _formWidgets[fieldName];
                    widget.set("parent", this);
                    if (widget.stopEditOnBlur === true) {
                        this.connect(widget, "onBlur", this.onStopEdit);
                    }
                }

                _formWidgets = null;
            });

            var editorParams = lang.mixin({ intermediateChanges: true }, this.editorParams);

            // Add event only when editor type is FormContainer
            if (this.editorWidgetType === this.formContainerWidgetType) {
                lang.mixin(editorParams, {
                    onFieldCreated: onFieldCreatedHandler,
                    onFormCreated: onFormCreatedHandler
                });
            }

            var def = new Deferred();

            //Change . to /
            var widgetType = epiString.slashName(this.editorWidgetType);

            // Create editor widget
            require([widgetType], lang.hitch(this, function (editorClass) {
                var editor = new editorClass(editorParams);
                this.editorWidget = editor;

                // Create dialog and set content
                var dialog = this._createDialog(editor);

                this._handlers = [
                    this.connect(dialog, "onButtonClose", this._onButtonClose),
                    this.connect(dialog, "onCancel", this._onDialogCancel),
                    this.connect(dialog.doneButtonNode, "onClick", this._onButtonClose),
                    this.connect(editor, "onChange", this._onChange),
                    this.connect(editor, "onKeyPress", "_onEditorKeyPress")
                ];
                this._dialog = dialog;

                // start editor if we created it
                if (this._createdEditor && this.editorWidget.startup) {
                    this.editorWidget.startup();
                }

                def.resolve();
            }));

            return def;
        },

        _onDialogCancel: function () {
            this.cancel();
        },

        _destroyDialog: function () {
            array.forEach(this._handlers, function (handle) { handle.remove(); });
            this._handlers = null;

            if (this._dialog) {
                this._dialog.destroy();
                this._dialog = null;
            }

            if (this.editorWidget) {
                this.editorWidget.destroy();
                this.editorWidget = null;
            }
        },

        _removeEditingFeatures: function () {
            if (this._dialog.open) {
                this._dialog.hide();
            }
        },

        _onTryToStopWithInvalidValue: function () {
            // force the editor to show any validation message
            // trigger a blur for the widget and then refocus it
            // this is a workaround to get any validation feedback
            // from widgets that only displays validation message when 
            // input fields are blurred
            dijit.focus(this._dialog.titleNode);

            if (this.editorWidget.focus) {
                this.editorWidget.focus();
            }
        },

        _onButtonClose: function () {
            // summary:
            //    Stop editing when the dialog is hidden.
            // tags:
            //    private

            if (!this.editorWidget.isShowingChildDialog) {
                this.tryToStopEditing(false);
            }
        }

    });

});