﻿define("epi-cms/contentediting/editors/model/CollectionEditorItemModel", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful"
], function (
// Dojo
    declare,
    lang,
    Stateful
) {
    // module: 
    //      epi-cms/contentediting/editors/model/CollectionEditorItemModel.
    // summary:
    //      Item model class for collection editor.

    return declare([Stateful], {
        // _itemData: Object
        //      The original item
        _itemData: null,


        // name: String
        //      Item name. Used for item's dnd creator.
        name: null,

        fromItemData: function (itemData) {
            // summary:
            //      Create item model object from raw item data.
            // itemData: Object
            //      The raw item data.
            // tags:
            //      public

            lang.mixin(this, itemData);

            this._itemData = itemData;
            this.name = this.name || this._itemData.toString();
        },

        toItemData: function () {
            // summary:
            //      Unwrap item model and return raw item data.
            // tags:
            //      public

            var result = {};

            for (var property in this._itemData) {
                if (this._itemData.hasOwnProperty(property)) {
                    result[property] = this.get(property);
                }
            }

            return result;
        }
    });
});