﻿define("epi-cms/contentediting/_ContentEditingNotification", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/Stateful",
    "dojo/when",
// epi
    "epi",
    "epi/dependency"
],

function (
// dojo
    declare,
    lang,

    Stateful,
    when,
// epi
    epi,
    dependency
) {

    // summary:
    //      Base class for content editing notification
    // tags:
    //      protected

    return declare([Stateful], {

        // invokeActionValue: [public] Object
        //      Data that used to fire action on the store when its value changed
        invokeActionValue: null,

        // notification: [public] Object|Array
        //      Notification object format: { content: "notification message", commands: [] }
        notification: null,

        // _storeName: [protected] String
        //      Name of the store
        _storeName: null,

        // _store: [protected] dojo.store.api.Store
        //      Notification store
        _store: null,

        // _invokeActionProperty: [protected] String
        //      Property name that used to fire action on the store
        _invokeActionProperty: "invokeActionValue",

        postscript: function () {
            this.inherited(arguments);

            this._setupStore();
            this.watch(this._invokeActionProperty, lang.hitch(this, this._invokeActionPropertyWatchHandler));
        },

        _setupStore: function () {
            // summary:
            //      Setup store if the concreate class need it
            // tags:
            //      private

            if (!this._store && this._storeName) {
                var registry = dependency.resolve("epi.storeregistry");
                this._store = registry.get(this._storeName);
            }
        },

        _executeAction: function (/*Object*/value) {
            // summary:
            //      Perform action on the store
            // tags:
            //      protected, extension

            return value;
        },

        _onExecuteSuccess: function () {
            // summary:
            //      Perform action(s) when store's function executed success
            // tags:
            //      protected, extension
        },

        _onExecuteFailed: function () {
            // summary:
            //      Perform action(s) when store's function executed fail 
            // tags:
            //      protected, extension
        },

        _invokeActionPropertyWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/value) {
            // summary:
            //      Call store's function when the given property have changed
            // tags:
            //      private

            if (value == null || epi.areEqual(oldValue, value)) {
                return;
            }

            when(this._executeAction(value), lang.hitch(this, this._onExecuteSuccess), lang.hitch(this, this._onExecuteFailed));
        },

        _setNotification: function (/*Object|Array*/notification) {
            // summary:
            //      Stub to set notification
            // notification:
            //      Notification object format: { content: "notification message", commands: [] }
            // tags:
            //      protected

            this.set("notification", notification);
        }

    });

});