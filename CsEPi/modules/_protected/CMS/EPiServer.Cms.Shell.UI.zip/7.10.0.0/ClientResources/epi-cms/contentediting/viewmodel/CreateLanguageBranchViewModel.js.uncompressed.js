﻿define("epi-cms/contentediting/viewmodel/CreateLanguageBranchViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

// epi
    "epi-cms/contentediting/viewmodel/CreateContentViewModel"
],

function (
// dojo
    declare,
    lang,
    when,

// epi
    CreateContentViewModel
) {

    // module:
    //    epi-cms/contentediting/viewmodel/CreateLanguageBranchViewModel
    // summary:
    //      View model of epi-cms/contentediting/CreateLanguageBranch component.
    // tags:
    //      public

    return declare([CreateContentViewModel], {

        // languageBranch: String
        //      Language branch on which the new content is created.
        languageBranch: null,

        // masterLanguageVersionId: String
        //      Content link of the master language version.
        masterLanguageVersionId: null,

        postscript: function () {

            // always start with second step
            this.wizardStep = 1;
            this.startWizardStep = 1;

            this.inherited(arguments);
        },

        update: function (settings) {
            // summary:
            //      Update the component with new settings.
            // description:
            //      Override the base to set other properties (languageBranch, masterLanguageVersionId, contentName) with values provided by the component settings requested.
            // settings: Object
            //      The settings object.
            // tags:
            //      public

            var masterContent = settings.contentData;
            var languageBranch = settings.languageBranch;

            return when(this.contentDataStore.get(masterContent.parentLink), lang.hitch(this, function (parent) {
                var baseResult = CreateContentViewModel.prototype.update.apply(this, [{
                    requestedType: masterContent.typeIdentifier,
                    parent: parent,
                    contentTypeId: masterContent.contentTypeID
                }]);

                this.set("languageBranch", languageBranch);
                this.set("masterLanguageVersionId", masterContent.contentLink);
                this.set("contentName", masterContent.name);

                return baseResult;
            }));
        },

        _isRequired: function (property) {
            // summary:
            //      Checks if the given property is required.
            // property: Object
            //      The metadata property.
            // tags:
            //      protected, extension

            return this.inherited(arguments) && (!this.languageBranch || property.settings.isLanguageSpecific === true);
        },

        buildContentObject: function () {
            // summary:
            //      Build up the content object to create from model properties.
            // description:
            //      Override to set languageBranch and masterLanguageVersionId on the result.
            // tags:
            //      protected

            var content = this.inherited(arguments);

            lang.mixin(content, {
                languageBranch: this.languageBranch,
                masterLanguageVersionId: this.masterLanguageVersionId
            });

            return content;
        }

    });

});