﻿define("epi-cms/ApplicationSettings", [
],

function (
) {
    // module:
    //      epi-cms/ApplicationSettings
    // description:
    //      Application settings for CMS.
    // tags:
    //      public

    return {
    };
});