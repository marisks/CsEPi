﻿define("epi-cms/contentediting/editors/PreviewableDateTimeEditor", [
    "dojo/_base/declare",
    "dojo/dom-construct",

    "epi/datetime",
    "epi/shell/widget/DateTimeSelectorDropDown",
    "epi-cms/contentediting/editors/_PreviewableEditor"

], function (
    declare,
    domConstruct,

    epiDate,
    DateTimeSelectorDropDown,
    _PreviewableEditor
) {
    return declare([_PreviewableEditor], {
        required: false,

        // controlParams: Array
        //      Properties to copy from this widget into the wrapped control
        controlParams: ["required"],

        buildRendering: function () {
            this.control = new DateTimeSelectorDropDown({ datePackage: null });
            this.inherited(arguments);
        },

        onChange: function (val) {
            this.set("labelValue", epiDate.toUserFriendlyHtml(val));
        }
    });
});